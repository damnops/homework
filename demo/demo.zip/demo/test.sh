#!/bin/sh

echo 'Running unit test'
sleep 5
echo 'Pass'

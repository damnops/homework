#!/bin/sh

jar -cvf hello.war index.jsp
